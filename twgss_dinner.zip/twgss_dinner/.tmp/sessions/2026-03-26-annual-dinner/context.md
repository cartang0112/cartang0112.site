# Task Context: Annual Dinner Database Webpage

Session ID: 2026-03-26-annual-dinner
Created: 2026-03-26T10:13:00Z
Status: in_progress

## Current Request
Create a webpage for annual dinner with a database of 3 columns: Name, Year, Table Number. When user searches by name or year, the rest of the fields will show up.

## Context Files (Standards to Follow)
None - fresh project with no existing context files

## Reference Files (Source Material)
None

## External Docs Fetched
None

## Components
- Single HTML file with embedded CSS and JavaScript
- Embedded JSON database
- Search functionality

## Constraints
- Simple, standalone solution (no server needed)
- Real-time search
- Clean, elegant design

## Exit Criteria
- [x] Webpage loads without errors
- [x] Search by name works
- [x] Search by year works
- [x] Results display all 3 fields
